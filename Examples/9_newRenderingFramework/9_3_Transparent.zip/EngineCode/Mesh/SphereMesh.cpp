﻿#include "SphereMesh.h"
#include "Core/MeshType.h"
#include "../Mesh/Core/MeshManager.h"
#include "../Core/Construction/MacroConstruction.h"
#include "../Component/Mesh/SphereMeshComponent.h"

GSphereMesh::GSphereMesh()
{
	SetMeshComponent(ConstructionObject<CSphereMeshComponent>());
}


void GSphereMesh::Init()
{
	Super::Init();


}



void GSphereMesh::Draw(float DeltaTime)
{
	Super::Draw(DeltaTime);


}


void GSphereMesh::CreateMesh(float InRadius, uint32_t InAxialSubdivision, uint32_t InHeightSubdivision, bool bReverse)
{
	CREATE_RENDER_DATA(CSphereMeshComponent, InRadius, InAxialSubdivision, InHeightSubdivision, bReverse);
}