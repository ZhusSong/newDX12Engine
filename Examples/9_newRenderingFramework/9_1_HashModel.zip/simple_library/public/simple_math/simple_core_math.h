﻿// 25.6.8 李
#pragma once
#include "math_libray.hpp"
#include "simple_math.h"
#include "math_utils.h"

//向量
#include "transformation/vector/vector_2d.h"
#include "transformation/vector/vector_3d.h"
#include "transformation/vector/vector_4d.h"
#include "transformation/vector/vector_2id.h"
#include "transformation/vector/vector_3id.h"
#include "transformation/vector/vector_4id.h"
#include "transformation/vector/vector_color.h"

//矩阵
#include "transformation/matrix/matrix_2x2.h"
#include "transformation/matrix/matrix_3x3.h"
#include "transformation/matrix/matrix_4x4.h"

//图元
#include "transformation/primitives/triangle.h"
#include "transformation/primitives/line.h"