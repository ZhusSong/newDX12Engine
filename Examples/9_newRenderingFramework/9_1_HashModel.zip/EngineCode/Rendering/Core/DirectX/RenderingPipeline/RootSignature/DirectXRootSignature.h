﻿#pragma once
#include "../../../../../Interface/DirectXDeviceInterface.h"
#include "../StaticSampler/StaticSamplerObject.h"

struct FDirectXRootSignature :public IDirectXDeviceInterface_Struct
{
	FDirectXRootSignature();

	void BuildRootSignature(UINT InTextureNum = 1);

	void PreDraw(float DeltaTime);
	void Draw(float DeltaTime);
	void PostDraw(float DeltaTime);

	ID3D12RootSignature* GetRootSignature() { return RootSignature.Get(); }

private:
	ComPtr<ID3D12RootSignature> RootSignature;
	FStaticSamplerObject StaticSamplerObject;
};