#pragma once

// 相机状态枚举
enum ECmeraType
{
	CameraRoaming,
	ObservationObject,
};