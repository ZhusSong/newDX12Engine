#pragma once

#include "../../Core/CoreObject/CoreMinimalObject.h"

class CComponent :public CCoreMinimalObject
{

};