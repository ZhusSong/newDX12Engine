#pragma once
#include "simple_library/public/simple_channel/simple_core/simple_connetion.h"

class FSimpleTCPConnetion :public FSimpleConnetion
{
public:


};