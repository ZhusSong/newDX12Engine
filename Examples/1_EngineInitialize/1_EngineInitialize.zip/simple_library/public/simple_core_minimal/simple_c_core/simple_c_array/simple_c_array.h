#pragma once
#include "simple_c_array_string.h"

//_CRT_BEGIN_C_HEADER
//SIMPLE_ARRAY_C(simple_c_char,char);
//SIMPLE_ARRAY_C(simple_c_float, float);
//SIMPLE_ARRAY_C(simple_c_int, int);
//SIMPLE_ARRAY_C(simple_c_double, double);
//SIMPLE_ARRAY_C(simple_c_longlong, long long);
//_CRT_END_C_HEADER