#include "ViewportTransformation.h"

FViewportTransformation::FViewportTransformation()
    :ViewProjectionMatrix(EngineMath::IdentityMatrix4x4())
{

}