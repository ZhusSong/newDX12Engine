#include "RenderingEngine.h"

// 设置主视口
void CRenderingEngine::SetMainWindowsHandle(HWND InNewMainWindowsHandle)
{
	MainWindowsHandle = InNewMainWindowsHandle;
}
