#pragma once
#include "MeshType.h"

struct FObjectTransform
{
	FObjectTransform();

	XMFLOAT4X4 World;

};
