// 平行光组件
#include "ParallelLightComponent.h"