#include "simple_net_drive_udp.h"

FSimpleUDPNetDrive::FSimpleUDPNetDrive(ESimpleDriveType InDriveType)
{

}
