#include "ObjectTransform.h"

FObjectTransform::FObjectTransform()
    :World(EngineMath::IdentityMatrix4x4())
{
}
