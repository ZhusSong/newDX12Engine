#include "Input.h"

FCaptureOnMousesWheelsDelegate MousesWheelsDelegate;
FCaptureOnMousesDelegate MouseDownDelegate;
FCaptureOnMousesDelegate MouseUpDelegate;
FCaptureOnMousesDelegate MouseMoveDelegate;