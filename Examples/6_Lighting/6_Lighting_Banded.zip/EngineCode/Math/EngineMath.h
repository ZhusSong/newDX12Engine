#pragma once
#include "../EngineMinimal.h"
#include <DirectXMath.h>

// 数学相关
namespace EngineMath
{
	XMFLOAT4X4 IdentityMatrix4x4();
}
