#pragma once

#define CVARIABLE(...) 
#define CDIAPER(...) 