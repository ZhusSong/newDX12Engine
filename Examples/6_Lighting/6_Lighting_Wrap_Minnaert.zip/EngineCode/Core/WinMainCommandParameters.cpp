#include "WinMainCommandParameters.h"

FWinMainCommandParameters::FWinMainCommandParameters(HINSTANCE InhInstance, HINSTANCE InprevInstance, PSTR IncmdLine, int InshowCmd)
	:HInstance(InhInstance)
	, PrevInstance(InprevInstance)
	, CmdLine(IncmdLine)
	, ShowCmd(InshowCmd)
{

}
