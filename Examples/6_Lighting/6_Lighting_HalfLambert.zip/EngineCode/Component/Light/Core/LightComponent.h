// 灯光组件
#pragma once
#include "../../TransformComponent.h"

class CLightComponent :public CTransformComponent
{

};
