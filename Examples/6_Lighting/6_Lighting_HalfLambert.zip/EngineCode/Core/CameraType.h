#pragma once

// 相机状态枚举
enum ECmeraType
{
	// 自由视角
	CameraRoaming,

	// 固定视角
	ObservationObject,
};