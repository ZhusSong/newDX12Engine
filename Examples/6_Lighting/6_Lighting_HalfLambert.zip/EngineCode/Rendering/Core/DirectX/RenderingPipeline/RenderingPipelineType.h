#pragma once

enum EPipelineState
{
	// 实体
	GrayModel = 4,

	// 线框
	Wireframe = 5,
};