// 平行光组件
#pragma once
#include "Core/LightComponent.h"

class CParallelLightComponent :public CLightComponent
{
public:
};
