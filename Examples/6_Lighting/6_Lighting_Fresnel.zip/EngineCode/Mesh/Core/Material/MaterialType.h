
enum EMaterialType
{
	Lambert = 0,
	HalfLambert,
	Phong,
	Fresnel=100, //测试用，并非单独材质
	Max,
};