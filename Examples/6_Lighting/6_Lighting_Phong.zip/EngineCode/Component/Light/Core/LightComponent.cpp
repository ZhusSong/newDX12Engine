// 灯光组件
#include "LightComponent.h"