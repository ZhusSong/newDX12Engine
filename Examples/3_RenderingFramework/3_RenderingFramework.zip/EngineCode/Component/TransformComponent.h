#pragma once
#include "Core/Component.h"


class CTransformComponent :public CComponent
{
public:


};
