﻿// 2025.4 李
#include "simple_library/public/simple_math/transformation/vector/vector_4id.h"

fvector_4id::fvector_4id(int in_value)
	: x(in_value)
	, y(in_value)
	, z(in_value)
	, w(in_value)
{

}

fvector_4id::fvector_4id(int a, int b, int c, int d)
	: x(a)
	, y(b)
	, z(c)
	, w(d)
{}
